import cv2
from PIL import Image 
import numpy as np
import numba as nb
import os
import pickle
import sys
import concurrent.futures
from agec import *
from gaussian2d import gaussian2d
from gettestargs import gettestargs
from hashkey import hashkey
from math import floor, ceil
from scipy import interpolate
import warnings
warnings.filterwarnings("ignore")

imagecount = 1
imagelist = []

def join(image):
	name = image.split('.')[0]
	name = "results"+ name[4:]
	im1 = cv2.imread(name + '$1_result.bmp')
	im2 = cv2.imread(name + '$2_result.bmp')
	im3 = cv2.imread(name + '$3_result.bmp')
	im4 = cv2.imread(name + '$4_result.bmp')
	im5 = cv2.imread(name + '$5_result.bmp')
	im6 = cv2.imread(name + '$6_result.bmp')
	im7 = cv2.imread(name + '$7_result.bmp')
	im8 = cv2.imread(name + '$8_result.bmp')
	im_v = cv2.vconcat([im1, im2, im3, im4, im5, im6, im7, im8])
	cv2.imwrite( name + "_result.bmp", im_v)

def split(image):
    img = Image.open(image)
    width, height = img.size
    upper = 0
    left = 0
    slice_size = int(ceil(height/8))
    slices = int(ceil(height/slice_size))

    count = 1
    lower = 0
    for slice in range(slices):
        #if we are at the end, set the lower bound to be the bottom of the image
        if count == slices:
            lower = height
        else:
            lower += slice_size

        bbox = (left, upper, width, lower)
        working_slice = img.crop(bbox)
        upper += slice_size
        #save the slice
        working_slice.save( os.path.join('results/', os.path.splitext(os.path.basename(image))[0] + "$" + str(count)+".bmp") )
        count +=1  

def upscale(image):
	global imagecount
	global imagelist
	# print('\r', end='')
	# print(' ' * 60, end='')
	# print('\rUpscaling image ' + str(imagecount) + ' of ' + str(len(imagelist)) + ' (' + image + ')')
	origin = cv2.imread(image)
	# Extract only the luminance in YCbCr
	ycrcvorigin = cv2.cvtColor(origin, cv2.COLOR_BGR2YCrCb)
	grayorigin = ycrcvorigin[:,:,0]
	# Normalized to [0,1]
	grayorigin = cv2.normalize(grayorigin.astype('float'), None, grayorigin.min()/255, grayorigin.max()/255, cv2.NORM_MINMAX)
	# Upscale (bilinear interpolation)
	heightLR, widthLR = grayorigin.shape
	heightgridLR = np.linspace(0,heightLR-1,heightLR)
	widthgridLR = np.linspace(0,widthLR-1,widthLR)
	bilinearinterp = interpolate.interp2d(widthgridLR, heightgridLR, grayorigin, kind='linear')
	heightgridHR = np.linspace(0,heightLR-0.5,heightLR*2)
	widthgridHR = np.linspace(0,widthLR-0.5,widthLR*2)
	upscaledLR = bilinearinterp(widthgridHR, heightgridHR)
	# Calculate predictHR pixels
	heightHR, widthHR = upscaledLR.shape
	predictHR = np.zeros((heightHR-2*margin, widthHR-2*margin))
	operationcount = 0
	totaloperations = (heightHR-2*margin) * (widthHR-2*margin)
	for row in range(margin, heightHR-margin):
		for col in range(margin, widthHR-margin):
			# if round(operationcount*100/totaloperations) != round((operationcount+1)*100/totaloperations):
				# print('\r|', end='')
				# print('♥' * round((operationcount+1)*100/totaloperations/2), end='')
				# print(' ' * (50 - round((operationcount+1)*100/totaloperations/2)), end='')
				# print('|  ' + str(round((operationcount+1)*100/totaloperations)) + '%', end='')
				# sys.stdout.flush()
			# operationcount += 1
			# Get patch
			patch = upscaledLR[row-patchmargin:row+patchmargin+1, col-patchmargin:col+patchmargin+1]
			patch = patch.ravel()
			# Get gradient block
			gradientblock = upscaledLR[row-gradientmargin:row+gradientmargin+1, col-gradientmargin:col+gradientmargin+1]
			# Calculate hashkey
			gy, gx = np.gradient(gradientblock)
			angle, strength, coherence = hashkey(Qangle, weighting, gy, gx)
			# Get pixel type
			pixeltype = ((row-margin) % R) * R + ((col-margin) % R)
			predictHR[row-margin,col-margin] = patch.dot(h[angle,strength,coherence,pixeltype])
	# Scale back to [0,255]
	predictHR = np.clip(predictHR.astype('float') * 255., 0., 255.)
	# Bilinear interpolation on CbCr field
	result = np.zeros((heightHR, widthHR, 3))
	y = ycrcvorigin[:,:,0]
	bilinearinterp = interpolate.interp2d(widthgridLR, heightgridLR, y, kind='linear')
	result[:,:,0] = bilinearinterp(widthgridHR, heightgridHR)
	cr = ycrcvorigin[:,:,1]
	bilinearinterp = interpolate.interp2d(widthgridLR, heightgridLR, cr, kind='linear')
	result[:,:,1] = bilinearinterp(widthgridHR, heightgridHR)
	cv = ycrcvorigin[:,:,2]
	bilinearinterp = interpolate.interp2d(widthgridLR, heightgridLR, cv, kind='linear')
	result[:,:,2] = bilinearinterp(widthgridHR, heightgridHR)
	result[margin:heightHR-margin,margin:widthHR-margin,0] = predictHR
	result = cv2.cvtColor(np.uint8(result), cv2.COLOR_YCrCb2RGB)
	cv2.imwrite('results/' + os.path.splitext(os.path.basename(image))[0] + '_result.bmp', (cv2.cvtColor(result, cv2.COLOR_RGB2BGR)) )
	imagecount += 1
	return '.'

args = gettestargs()

# Define parameters
R = 2
patchsize = 11
gradientsize = 9
Qangle = 24
Qstrength = 3
Qcoherence = 3
trainpath = 'test'
resultpath= 'results'
# Calculate the margin
maxblocksize = max(patchsize, gradientsize)
margin = floor(maxblocksize/2)
patchmargin = floor(patchsize/2)
gradientmargin = floor(gradientsize/2)

# Read filter from file
filtername = 'filter.p'
if args.filter:
	filtername = args.filter
with open(filtername, "rb") as fp:
	h = pickle.load(fp)

# Matrix preprocessing
# Preprocessing normalized Gaussian matrix W for hashkey calculation
weighting = gaussian2d([gradientsize, gradientsize], 2)
weighting = np.diag(weighting.ravel())

# Get image list
# for parent, dirnames, filenames in os.walk(trainpath):
# 	for filename in filenames:
# 		if filename.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
# 			imagelist.append(os.path.join(parent, filename))

# for image in imagelist:
# 	upscale(image)
mainlist = []
with concurrent.futures.ProcessPoolExecutor() as executor:

	for parent, dirnames, filenames in os.walk(trainpath):
		for filename in filenames:
			if filename.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
				mainlist.append(os.path.join(parent, filename))

	for mainimg in mainlist:
		# print(mainimg)	#test/1.png  test/apple.jpeg
		split(mainimg)	#in results apple$1_result.bmp 1$1_result.bmp

		prefix = mainimg.split('.')[0]
		# print(prefix)	test/apple
		prefix = prefix[5:]
		# print(prefix) apple
		imagelist = []
		for parent, dirnames, filenames in os.walk(resultpath):
			for filename in filenames:
				if filename.endswith((prefix+'$1.bmp',prefix+'$2.bmp',prefix+'$3.bmp',prefix+'$4.bmp',prefix+'$5.bmp',prefix+'$6.bmp',prefix+'$7.bmp',prefix+'$8.bmp')):
					imagelist.append(os.path.join(parent, filename))

		print('PROCESSING, please wait ☻')
		pro=12.5
		for image, thumbnail_file in zip(imagelist,executor.map(upscale,imagelist)):
			print("\n"+ str(pro) + " percent done" + thumbnail_file)
			pro+=12.5

		join(mainimg)
		# apple_result
		for items in imagelist:
			os.remove(items)
			os.remove(items.split('.')[0]+"_result.bmp")


print('\r', end='')
print(' ' * 60, end='')
print('\rFinished.')
