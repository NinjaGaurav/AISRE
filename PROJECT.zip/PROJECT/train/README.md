## Folder description

Put your training image in this folder.
